<?php /*a:1:{s:55:"/data/chat/application/index/view/login/registered.html";i:1567001976;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content=""/>
<title>注册</title>
<link rel="stylesheet" href="/static/login/css/jq22.css">
</head>
<body>
<!-- begin -->
<div id="login">
    <div class="wrapper">
        <div class="login">
            <form   class="container offset1 loginform">
                <div id="owl-login">
                    <div class="hand"></div>
                    <div class="hand hand-r"></div>
                    <div class="arms">
                        <div class="arm"></div>
                        <div class="arm arm-r"></div>
                    </div>
                </div>
                <div class="pad">
                     <div class="control-group">
                        <div class="controls">
                            <label for="name" class="control-label fa fa-user"></label>
                            <input id="username" type="text" name="username" placeholder="用户名" tabindex="1" autofocus="autofocus" class="form-control input-medium">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label for="email" class="control-label fa fa-envelope"></label>
                            <input id="email" type="email" name="email" placeholder="电子邮箱" tabindex="1" autofocus="autofocus" class="form-control input-medium">
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="controls">
                            <label for="password" class="control-label fa fa-asterisk"></label>
                            <input id="password" type="password" name="password" placeholder="密码" tabindex="2" class="form-control input-medium">
                        </div>
                    </div>
                     <div class="control-group">
                        <div class="controls">
                            <label for="password" class="control-label fa fa-asterisk"></label>
                            <input id="repassword" type="password" name="repassword" placeholder="确认密码" tabindex="2" class="form-control input-medium">
                        </div>
                    </div>
                </div>
                <div class="form-actions"><a href="<?php echo url('/login'); ?>" tabindex="6" class="btn btn-link text-muted">返回登录</a>
                    <button type="button" tabindex="4" class="btn btn-primary" onclick="register()">注册</button>
                </div>
            </form>
        </div>
    </div>
    <script src="/static/login/js/jquery.min.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        //注册
        function register() {

            var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
            var username = $("#username").val();
            var email = $("#email").val();
            var password = $("#password").val();
            var repassword = $("#repassword").val();

            if(!username){
                swal ( "用户名不存在" ,  "Something went wrong!" ,  "error" );return false;
            }

            if(!reg.test(email))
            {
                swal ( "邮箱格式不正确" ,  "Something went wrong!" ,  "error" );return false;
            }

            if(password !== repassword){
                swal ( "两次密码不正确" ,  "Something went wrong!" ,  "error" );return false;
            }

            var data = $('form').serialize();
            axios.post('/adduser',data)
                .then(function (response) {
                    if (response.data.status == 1){
                        swal(response.data.msg, '', 'success').then(function () {
                            // 用户点击弹框上按钮时重新加载页面
                            window.location.href = "<?php echo url('/login'); ?>";
                        });
                    }else{
                        swal (response.data.msg,'',  "error" );

                    }
                })
                .catch(function (error) {
                    swal ( "系统错误" , error ,  "error" );return false;
                });
        }
    </script>
    <script>
    $(function() {


        $('#login #password').focus(function() {
            $('#owl-login').addClass('password');
        }).blur(function() {
            $('#owl-login').removeClass('password');
        });
    });
    </script>
</div>
<!-- end -->
</body>
</html>