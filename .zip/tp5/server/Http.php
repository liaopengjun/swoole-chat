<?php

class Http{

    CONST HOST = "0.0.0.0";
    CONST PORT = 8811;
    public $http = null;

    public function __construct() {

        $this->http = new swoole_http_server(self::HOST, self::PORT);

        $this->http->set(
            [
                'enable_static_handler' => true,
                'document_root' => "/data/tp5/public/static",
                'worker_num' => 4,
                'task_worker_num' => 4,
            ]
        );

        $this->http->on("workerstart", [$this, 'onWorkerStart']);
        $this->http->on("request", [$this, 'onRequest']);
        $this->http->on("task", [$this, 'onTask']);
        $this->http->on("finish", [$this, 'onFinish']);
        $this->http->on("close", [$this, 'onClose']);

        $this->http->start();
    }
    /**
     * @param $server
     * @param $worker_id
     */
    public function onWorkerStart($server,  $worker_id){

        // 定义应用目录
        define('APP_PATH', __DIR__ . '/../application/');
        // 加载框架里面的文件
        require __DIR__ . '/../thinkphp/base.php';

    }

    /** 回调
     * @param $request
     * @param $response
     */
    public function onRequest($request, $response){
        $_SERVER  =  [];
        if(isset($request->server)) {
            foreach($request->server as $k => $v) {
                $_SERVER[strtoupper($k)] = $v;
            }
        }
        if(isset($request->header)) {
            foreach($request->header as $k => $v) {
                $_SERVER[strtoupper($k)] = $v;
            }
        }

        $_GET = [];
        if(isset($request->get)) {
            foreach($request->get as $k => $v) {
                $_GET[$k] = $v;
            }
        }
        $_POST = [];
        if(isset($request->post)) {
            foreach($request->post as $k => $v) {
                $_POST[$k] = $v;
            }
        }
        //返回http服务
        $_POST['http_server'] = $this->http;

        ob_start();
        // 执行应用并响应
        try {
            think\Container::get('app', [APP_PATH])
                ->run()
                ->send();
        }catch (\Exception $e) {
            // todo
        }

        $res = ob_get_contents();
        ob_end_clean();
        $response->end($res);

    }

    /**
     * @param $serv
     * @param $task_id
     * @param $src_worker_id
     * @param $data
     * @return string
     */
    public function onTask($serv, $task_id,$src_worker_id,$data){

            $obj = new app\common\task\Task();

            $action = $data['method'];
            $result = $obj->$action($data);

//            $sms = new app\common\juhe\Sms();
//            try{
//                $result =$sms->toSend($data['phone'],$data['code']);
//
//            } catch (\Exception $e){
//                    $e->getMessage();
//            }
//        print_r($data);
//        print_r($result);
//        print_r($data);
//        sleep(10);
//        return "on task finish";
        return $result;
    }

    /**
     * @param $serv
     * @param $task_id
     * @param $data
     */
    public function onFinish($serv,$task_id,$data){
        echo "client:{$task_id}\n";
        echo "finish-data-success:{$data}";
    }

    /** 监听关闭事件
     * @param $ws
     * @param $fd
     */
    public function onClose($ws, $fd){
        echo "client-{$fd} is closed\n";
    }



}
 new Http();