var wsServer = 'ws://jcsjasafxzhzsxc.club:8811';
var websocket = new WebSocket(wsServer);
websocket.onopen = function (evt) {
    console.log("开启服务1");
};

websocket.onclose = function (evt) {
    console.log("关闭1");
};

websocket.onmessage = function (evt) {
    console.log('接受消息1: ' + evt.data);
    push(evt.data);
};

websocket.onerror = function (evt, e) {
    console.log('Error occured: ' + evt.data);
};

function push(data) {
     data = JSON.parse(data);
     html = '<div class="frame">';
        html += '<h3 class="frame-header"><i class="icon iconfont icon-shijian"></i>第'+data.type+'节 02：30</h3>';
        html +=        '<div class="frame-item">';
        html +=        '<span class="frame-dot"></span>';
        html +=         '<div class="frame-item-author">';
        if(data.logo){
            html += '<img src="'+data.logo+'" width="20px" height="20px" />';
        }
        html +=         data.title+'</div>';
        html +=        '<p>'+data.content+'</p>';
        html +=         '</div>';
        html +=     '</div>';

    $("#match-result").prepend(html);

}