$(function () {
    //键盘回车事件
    $('#onMessage-btn').keydown(function (event) {
            if(event.keyCode ==13){
                var text = $(this).val();
                var url = "http://bbs.jcsjasafxzhzsxc.club:8811/?s=index/chats/index";
                var data = {"content":text,"game_id":1};
                $.post(url,data,function (data) {
                        $(this).val();
                },'json');

            }
    })
});