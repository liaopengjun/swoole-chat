var wsServer = 'ws://jcsjasafxzhzsxc.club:8812';
var websocket = new WebSocket(wsServer);
websocket.onopen = function (evt) {
    console.log("开启服务2");
};

websocket.onclose = function (evt) {
    console.log("关闭2");
};

websocket.onmessage = function (evt) {
    console.log(evt);

    console.log('接受消息2: ' + evt.data);
};

websocket.onerror = function (evt, e) {
    console.log('Error occured: ' + evt.data);
};

