<?php
namespace app\admin\controller;
use app\common\redis\Predis;
class Live
{
    public function push(){

        if(empty($_GET)){
            return json([
              'msg'=>'提交数据不能为空',
              'status'=>0
            ]);
        }

        //球队信息
        $teams = [
            1 => [
                'name' => '马刺',
                'logo' => '/live/imgs/team1.png',
            ],
            4 => [
                'name' => '火箭',
                'logo' => '/live/imgs/team2.png',
            ],
        ];

        $data = [
            'type' => intval($_GET['type']),
            'title' => !empty($teams[$_GET['team_id']]['name']) ?$teams[$_GET['team_id']]['name'] : '直播员',
            'logo' => !empty($teams[$_GET['team_id']]['logo']) ?$teams[$_GET['team_id']]['logo'] : '',
            'content' => !empty($_GET['content']) ? $_GET['content'] : '',
            'image' => !empty($_GET['image']) ? $_GET['image'] : '',
        ];
//        $client = Predis::getInstance()->sMembers('redis_sadd_key');
//        foreach ($client as $fd){
//            $_POST['http_server']->push($fd,json_encode($data));
//        }
        //异步处理
        // 赛况的基本信息入库   2、数据组织好 push到直播页面
        $taskData = [
            'method' => 'pushLive',
            'data' => $data
        ];

        $_POST['http_server']->task($taskData);

        return json([
            'msg'=>'发送成功',
            'status'=>1
        ]);

    }
}