<?php
namespace app\admin\controller;

class Image
{
    public function index(){

        $file = request()->file('file');
        $info = $file->move('../public/static/upload');
        if($info) {

            $data = [
                'status'=>1,
                'image' => "http://bbs.jcsjasafxzhzsxc.club:8811"."/upload/".$info->getSaveName(),
            ];

            return json($data);
        }else {

            $data = [
                'status'=>0,
            ];

            return json($data);

        }
    }
}