<?php

namespace app\common\task;
use app\common\juhe\Sms;
use app\common\redis\Predis;

class Task{
    //异步处理短信发送
    public function sendSms($data){

        $sms = new Sms();
        try{
           $result =$sms->toSend($data['phone'],$data['code']);
        } catch (\Exception $e){
               return false;
        }
       $sendStatus = json_decode($result,true);

        if($sendStatus['error_code'] == 0){

            //redis存储
            Predis::getInstance()->set(Predis::smsKey($data['phone']), $data['code']);
            return true;

        }else{
            return false;

         }
        return true;



    }
    //异步发布消息
    public function pushLive($data,$serv){
        $client = Predis::getInstance()->sMembers('redis_sadd_key');
        foreach ($client as $fd){
            $serv->push($fd,json_encode($data));
        }

    }
   
}