<?php

namespace app\index\controller;
use app\common\juhe\Sms;
use app\common\redis\Predis;

class Send
{

    public function index()
    {

        $phone = $_GET['phone_num'];

        //验证手机号
        $result = preg_match('^1(3|4|5|7|8)[0-9]\d{8}$^', $phone);
        $code  =rand(000000,999999);

        $taskData = [
          'phone'=>$phone,
          'code' =>$code,
            'method'=>'sendSms'
        ];
        $_POST['http_server']->task($taskData);
        return 1;
//        if($result){
//                $sms = new Sms();
//                $result = $sms->toSend($phone,$code);
//                $sendStatus = json_decode($result,true);
//
//                if($sendStatus['error_code'] == 0){
//
//                    $redis = new \Swoole\Coroutine\Redis();
//                    $redis->connect(config('lredis.host'), config('lredis.port'));
//                    $redis->set(Predis::smsKey($phone), $code);//, config('lredis.out_time')
//
//                    return 1;
//
//                }else{
//
//                    return 0;
//
//                }
//        }else{
//            return 0;
//
//        }
    }

//
//    public function ex(){
//
//        $redis = new \Swoole\Coroutine\Redis();
//        $redis->connect(config('lredis.host'), config('lredis.port'));
//        $res = $redis->set(Predis::smsKey('15270914973'), 12344, config('lredis.out_time'));
//        echo $res;
//
//    }


}