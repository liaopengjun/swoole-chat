<?php
 namespace app\index\controller;
 use app\common\juhe\Sms;
 use app\common\redis\Predis;

 class  Login
 {
     public function index(){
         // phone code

         $phoneNum = intval($_GET['phone_num']);
         $code = intval($_GET['code']);

         if(empty($phoneNum) || empty($code)) {
             return json([
                 'status'=>0,
                 'msg'=>'不能为空',
             ]);
         }

         try{
                $RedisCode = Predis::getInstance()->get(Predis::smsKey($phoneNum));
         } catch (\Exception $e){
                return $e->getMessage();
         };


         if($RedisCode == $code){

             // 写入redis
            $data = [
                'user' => $phoneNum,
                'srcKey' => md5(Predis::userkey($phoneNum)),
                'time' => time(),
                'isLogin' => true,
            ];

            Predis::getInstance()->set(Predis::userkey($phoneNum), $data);

             return json([
                 'status'=>1,
                 'msg'=>'登录成功',
             ]);

         }else{
             return json([
                 'status'=>0,
                 'msg'=>'验证码已过期',
             ]);
         }

     }
 }