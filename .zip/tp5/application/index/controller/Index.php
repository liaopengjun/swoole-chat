<?php
namespace app\index\controller;
class Index
{
    public function index()
    {
        print_r($_GET);
        return  'hello';
    }

    public function singwa() {
        print_r($_GET);

        return time();
    }

    public function hello($name = 'ThinkPHP5')
    {
        return 'hessdggsg' . $name.time();
    }

}
