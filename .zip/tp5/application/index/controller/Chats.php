<?php
namespace app\index\controller;

class  Chats
{
    public function index(){
        foreach($_POST['http_server']->ports[1]->connections as $fd) {
            $_POST['http_server']->push($fd,$fd);
        }
        return json([
            'status'=>0,
            'msg'=>'fanhui'
        ]);
    }
}